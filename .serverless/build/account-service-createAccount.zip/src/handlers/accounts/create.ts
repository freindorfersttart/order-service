import { APIGatewayProxyHandler } from 'aws-lambda'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const schema = z.object({
  bank_code: z.string(),
  bank_name: z.string(),
  account_name: z.string(),
  account_number: z.string(),
  agency_number: z.string(),
  ispb: z.string(),
  cnpj: z.string(),
  pix_keys: z.array(z.string()),
  daily_limit: z.number(),
  nightly_limit: z.number(),
  per_operation_limit: z.number(),
  integration_status: z.string(),
  active: z.boolean()
})

export const create: APIGatewayProxyHandler = async (event) => {
  try {
    const data = schema.parse(JSON.parse(event.body || '{}'))
    const account = await prisma.core_bank_accounts.create({ data })

    return {
      statusCode: 201,
      body: JSON.stringify(account)
    }
  } catch (err: any) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: err.message })
    }
  }
}
