import { APIGatewayProxyHandler } from 'aws-lambda'
import { prisma } from '@/lib/prisma'

export const getAll: APIGatewayProxyHandler = async () => {
  try {
    const accounts = await prisma.core_bank_accounts.findMany({
      orderBy: { created_at: 'desc' }
    })

    return {
      statusCode: 200,
      body: JSON.stringify(accounts)
    }
  } catch (err: any) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Erro ao buscar contas bancárias', message: err.message })
    }
  }
}
