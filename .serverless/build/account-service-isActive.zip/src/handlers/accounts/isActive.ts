import { APIGatewayProxyHandler } from 'aws-lambda'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const schema = z.object({
  active: z.boolean()
})

export const isActive: APIGatewayProxyHandler = async (event) => {
  try {
    const accountId = event.pathParameters?.id
    if (!accountId) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Account ID is required in path' })
      }
    }

    const body = JSON.parse(event.body || '{}')
    const parsed = schema.safeParse(body)

    if (!parsed.success) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Invalid payload', details: parsed.error.flatten() })
      }
    }

    const updated = await prisma.core_bank_accounts.update({
      where: { id: accountId },
      data: { active: parsed.data.active }
    })

    return {
      statusCode: 200,
      body: JSON.stringify(updated)
    }

  } catch (err: any) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Erro ao atualizar status da conta', message: err.message })
    }
  }
}
